package com.example.wallpaperchange;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.DrawableContainer;


import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends AppCompatActivity {
    Button dynwall;
    Timer mytimer;
    Drawable drawable;
    WallpaperManager wpr;
    int prev = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mytimer = new Timer();
        wpr = WallpaperManager.getInstance(this);
        dynwall = findViewById(R.id.button);
        dynwall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setWallpaper();
            }
        });
    }
    private void setWallpaper() {
        mytimer.schedule(new TimerTask() {
            @SuppressLint("MissingPermission")
            @Override
            public void run() {
                if (prev == 1) {
                    drawable = getResources().getDrawable(R.drawable.ww1);
                    prev = 2;
                } else if (prev == 2) {
                    drawable = getResources().getDrawable(R.drawable.ww2);
                    prev = 3;
                } else if (prev == 3) {
                    drawable = getResources().getDrawable(R.drawable.ww3);
                    prev = 4;
                }
                if (prev == 4) {
                    drawable = getResources().getDrawable(R.drawable.ww4);
                    prev = 1;
                }
                Bitmap
                        wallpaper = ((BitmapDrawable) drawable).getBitmap();
                try {
                    wpr.setBitmap(wallpaper);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }, 0, 3000);
    }
}