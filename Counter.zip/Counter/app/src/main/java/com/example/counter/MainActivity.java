package com.example.counter;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {
    Button b1, b2;
    TextView tc1;
    int i = 1;
    Handler h1 = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.bt1);
        b2 = findViewById(R.id.bt2);
        tc1 = findViewById(R.id.text3);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                h1.postDelayed(updateTimerThread, 0);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                h1.removeCallbacks(updateTimerThread);
            }
        });
    }

    private final Runnable updateTimerThread = new Runnable() {
        @Override
        public void run() {
            tc1.setText("" + i);
            h1.postDelayed(this, 1000);
            i++;
        }
    };
}